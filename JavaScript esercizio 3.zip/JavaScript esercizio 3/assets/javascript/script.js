var mele = 4, arance = 5;
var indefinita;
const anno = 2022;
var anna = 30;
var maria = 24;
var calcoloEta1 = anno - anna;
var calcoloEta2 = anno - maria;


succo()
function succo() {
    document.getElementById('corretta').innerHTML = `Succo con ${mele} mele e ${arance} arance`;
    document.getElementById('sbagliata').innerHTML = `Succo con ${mele + 2} mele e ${indefinita} arance`;
}

scriviMiaEta()
function eta(annoNascita) {
    let miaEta = anno - annoNascita
    return miaEta;
}
function scriviMiaEta() {
    document.getElementById('eta').innerHTML += eta(1999);
}


freccia = () => {
    document.getElementById('persona1').innerHTML = `L\'anno di nascita di Anna è il ${calcoloEta1} `;
    document.getElementById('persona2').innerHTML = `L\'anno di nascita di Maria è il ${calcoloEta2} `;
}
freccia()

ingredienti()
function ingredienti() {
    let pezziDiMela = mele + 5;
    let fetteDiArancia = arance * 3;
    torta(pezziDiMela, fetteDiArancia);
}
function torta(parametro1, parametro2) {
    document.getElementById('torta').innerHTML = `Torta con ${parametro1} fette di mela e ${parametro2} fette di arancia.`;
}

document.getElementById('calcola').addEventListener ('click', dato);
function dato () {
    document.getElementById('totale').innerHTML = `Il totale spesa è: ${spesa ()}€`;
}
function spesa() {
    let cibo = parseInt (document.getElementById('cibo').value);
    let detersivi = parseInt (document.getElementById('detersivi').value);
    let abiti = parseInt (document.getElementById('abiti').value);
    result = cibo + detersivi + abiti;
    return result;
}